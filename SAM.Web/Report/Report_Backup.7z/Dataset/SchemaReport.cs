﻿namespace SAM.Web.Report.Dataset
{
}

namespace SAM.Web.Report.Dataset
{


    public partial class SchemaReport
    {
    }
}
namespace SAM.Web.Report.Dataset {
    
    
    public partial class SchemaReport {
    }
}
